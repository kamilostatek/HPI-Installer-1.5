#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BASE=https://raw.githubusercontent.com/kamilostatek/HPI-1.5/main
NAME=HaierPi_1.5_alpha.tar.gz
WORK=$(mktemp -d /var/tmp/hpi-runtime.XXXXXXXX)
trap 'rm -rf -- "$WORK"' EXIT
# Verify downloaded archive against the published checksum.
command -v python3 >/dev/null || { echo 'Brak python3; zainstaluj python3 przed uruchomieniem instalatora.' >&2; exit 1; }
curl -fsSL --retry 3 --connect-timeout 20 "$BASE/SHA256SUMS" -o "$WORK/SHA256SUMS"
curl -fsSL --retry 3 --connect-timeout 20 "$BASE/$NAME" -o "$WORK/$NAME"
python3 - "$WORK" "$ROOT_DIR/app" <<'PY'
import hashlib, pathlib, sys, tarfile, shutil, ast
work, app = map(pathlib.Path, sys.argv[1:])
name = 'HaierPi_1.5_alpha.tar.gz'
archive = work / name
matches = [line.split()[0] for line in (work/'SHA256SUMS').read_text().splitlines() if len(line.split()) == 2 and line.split()[1].lstrip('*') == name]
if len(matches) != 1 or hashlib.sha256(archive.read_bytes()).hexdigest() != matches[0]:
    raise SystemExit('BŁĄD: suma SHA256 aplikacji niezgodna.')
roots = {'main.py','compressor_cycles.py','energy_meter.py','haierpi_maintenance.py','smart_anti_adapter.py','smart_anti_drive.py','smart_anti_onoff.py'}
stage = work/'stage'; stage.mkdir()
with tarfile.open(archive, 'r:gz') as tar:
    for member in tar:
        parts = pathlib.PurePosixPath(member.name).parts
        if not parts or parts[0] != 'HaierPi_1.5' or '..' in parts or not (member.isdir() or member.isfile()):
            raise SystemExit('BŁĄD: nieprawidłowa struktura archiwum.')
        if len(parts) == 1: continue
        rel = parts[1:]
        if rel[0] not in roots | {'static','templates','PyHaier','HPi'}: continue
        target = stage.joinpath(*rel)
        if member.isdir(): target.mkdir(parents=True, exist_ok=True); continue
        target.parent.mkdir(parents=True, exist_ok=True)
        with tar.extractfile(member) as src, target.open('wb') as dst: shutil.copyfileobj(src,dst)
for name in roots | {'static','templates','PyHaier','HPi'}:
    if not (stage/name).exists(): raise SystemExit('BŁĄD: brak '+name)
for f in stage.rglob('*.py'): ast.parse(f.read_text(encoding='utf-8'), feature_version=(3,9))
for name in roots | {'static','templates','PyHaier','HPi'}:
    dst=app/name
    if dst.is_dir(): shutil.rmtree(dst)
    elif dst.exists(): dst.unlink()
    shutil.move(str(stage/name), str(dst))
print('Pobrano i sprawdzono aplikację HaierPi 1.5.')
PY
